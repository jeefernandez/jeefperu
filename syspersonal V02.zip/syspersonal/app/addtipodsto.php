<?php
session_start();
error_reporting(0);
include('../includes/config.php');
include('../includes/funciones.php');
if(strlen($_SESSION['emplogin'])==0)
{   
 header('location:index.php');
}else{
if(isset($_POST['update']))
{

#Recibimos variables del formulario
$id=getCodigo($dbh,'tipo_descuento','iddescuento'); # Obtenemos el codigo del nuevo registro
$nametpla=$_POST['txtnpla']; 
$estado=1;
#$sql="INSERT INTO periodo(idperiodo,nameperiodo,namecorto,fechareg,estado) VALUES (:id,:deptname,:deptshortname,:fecha,:estado)";
$sql="INSERT INTO tipo_descuento(iddescuento,namedescuento,estado) VALUES ('$id','$nametpla','$estado')";
$query = $dbh->prepare($sql);
#echo "$id <hr> $sql <hr>";
#$query->execute();
#$query->bindParam(':idtipoplanilla',$id,PDO::PARAM_STR);
#$query->bindParam(':nameplanilla',$deptname,PDO::PARAM_STR);
#$query->bindParam(':estado',$estado,PDO::PARAM_STR);
#$query->bindParam(':fechareg',$fecha,PDO::PARAM_STR);
#$query->bindParam(':estado',estado,PDO::PARAM_STR);
$query->execute();

#$query = $dbh->prepare($sql);
#$pdoExec = $query->execute(array(":id"=>$id,":deptname"=>$deptname,":deptshortname"=>$deptshortname,":fecha"=>$fecha,":estado"=>$estado));
$msg="Registro de Tipo Descuento con exito";
header('location:tipodsto.php');
}

 ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        
        <!-- Title -->
        <title>Admin | Tipo Descuento - Actualización</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />
        
         <!-- Styles -->
        <link type="text/css" rel="stylesheet" href="../assets/plugins/materialize/css/materialize.min.css"/>
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="../assets/plugins/material-preloader/css/materialPreloader.min.css" rel="stylesheet"> 
        <link href="../assets/css/alpha.min.css" rel="stylesheet" type="text/css"/>
        <link href="../assets/css/custom.css" rel="stylesheet" type="text/css"/>
<style>
        .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #E0B769;
    color:#fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 5px;
    margin: 0 0 20px 0;
    background: #5cb85c;
    color:#fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
        </style>
    </head>
    <body>
  <?php include('../includes/header.php');?>
            
       <?php include('../includes/sidebar.php');?>
            <main class="mn-inner">
                <div class="row">
                    <div class="col s12">
                        <div class="page-title">Actualización de Tipos de Descuentos</div>
                    </div>
                    <div class="col s12 m12 l6">
                        <div class="card">
                            <div class="card-content">
                              
<div class="row">
<form class="col s12" name="adperiodo" method="post">
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
 else if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>


         <div class="row">
        <div class="input-field col s12">
<input id="txtnpla" type="text"  class="validate" autocomplete="off" name="txtnpla" value="<?php echo htmlentities($result->namedescuento);?>"  required>
          <label for="txtnpla">Nombre de Tipo Descuento </label>
           </div>




<div class="input-field col s12">
<a href='tipodsto.php' class="waves-effect waves-red btn deep-orange m-b-xs"> Cancelar</a>


<button type="submit" name="update" class="waves-effect waves-light btn indigo m-b-xs">Guardar</button>

</div>




                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                     
             
                   
                    </div>
                
                </div>
            </main>

        </div>
        <div class="left-sidebar-hover"></div>
        
        <!-- Javascripts -->
        <script src="../assets/plugins/jquery/jquery-2.2.0.min.js"></script>
        <script src="../assets/plugins/materialize/js/materialize.min.js"></script>
        <script src="../assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
        <script src="../assets/plugins/jquery-blockui/jquery.blockui.js"></script>
        <script src="../assets/js/alpha.min.js"></script>
        <script src="../assets/js/pages/form_elements.js"></script>
        
        <script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					});
		    </script>
    
        
    </body>
</html>
<?php } ?> 
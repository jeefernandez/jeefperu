<?php
session_start();
error_reporting(0);
include('../includes/config.php');
if(strlen($_SESSION['emplogin'])==0){   
header('location:index.php');
}else{
if(isset($_POST['update'])){
$did=intval($_GET['deptid']); 
$ndni=$_POST['txtdni'];
$fecn=$_POST['txtfecn'];
$ape=$_POST['txtaper'];
$nom=$_POST['txtnper'];
$dir=$_POST['txtdir'];
$ciu=$_POST['txtciu'];
$sexo=$_POST['lstsexo'];
$email=$_POST['txtemail'];
$tel=$_POST['txttel'];
$idcar=$_POST['lstcargo'];
$idar=$_POST['lstarea'];
$basico=$_POST['txtbasico'];
$sp=$_POST['lstsp'];
$nci=$_POST['txtnumci']; 

$sql="update personal set dno=:ndni,nombre=:nom,apellido=:ape,email=:email,sexo=:sexo,fechanac=:fecn,direccion=:dir,ciudad=:ciu,
telefono=:tel,area=:idar,cargo=:idcar,sueldo=:basico,sistema=:sp,numero=:nci where id=:did";

$query = $dbh->prepare($sql);
$query->bindParam(':ndni',$ndni,PDO::PARAM_STR);
$query->bindParam(':nom',$nom,PDO::PARAM_STR);
$query->bindParam(':ape',$ape,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':sexo',$sexo,PDO::PARAM_STR);
$query->bindParam(':fecn',$fecn,PDO::PARAM_STR);
$query->bindParam(':dir',$dir,PDO::PARAM_STR);
$query->bindParam(':ciu',$ciu,PDO::PARAM_STR);
$query->bindParam(':tel',$tel,PDO::PARAM_STR);
$query->bindParam(':idar',$idar,PDO::PARAM_STR);
$query->bindParam(':idcar',$idcar,PDO::PARAM_STR);   
$query->bindParam(':basico',$basico,PDO::PARAM_STR);
$query->bindParam(':sp',$sp,PDO::PARAM_STR);
$query->bindParam(':nci',$nci,PDO::PARAM_STR);
$query->bindParam(':did',$did,PDO::PARAM_STR);
$query->execute();
$msg="Personal Actualizado con exito";
header('location:personal.php');
}

$sqlcargo = "SELECT * from cargos where est_cargo='1'";
$querycar = $dbh -> prepare($sqlcargo);
$querycar->execute();
$resultscar=$querycar->fetchAll(PDO::FETCH_OBJ);

$sqlArea = "SELECT * from areas where est_area='1'";
$queryAr = $dbh -> prepare($sqlArea);
$queryAr->execute();
$resultsAre=$queryAr->fetchAll(PDO::FETCH_OBJ); 
    ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        
        <!-- Title -->
        <title>Admin | Personal actualización</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />
        
        <!-- Styles -->
        <link type="text/css" rel="stylesheet" href="../assets/plugins/materialize/css/materialize.min.css"/>
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="../assets/plugins/material-preloader/css/materialPreloader.min.css" rel="stylesheet"> 
        <link href="../assets/css/alpha.min.css" rel="stylesheet" type="text/css"/>
        <link href="../assets/css/custom.css" rel="stylesheet" type="text/css"/>
  <style>
        .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
        </style>
    </head>
    <body>
  <?php include('../includes/header.php');?>
            
       <?php include('../includes/sidebar.php');?>
            <main class="mn-inner">
                <div class="row">
                    <div class="col s12">
                        <div class="page-title">Actualización de Personal</div>
                    </div>
                    <div class="col s12 m12 l6">
                        <div class="card">
                            <div class="card-content">
                              
                                <div class="row">
                                    <form class="col s12" name="chngpwd" method="post">
                                          <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
<?php 
$did=intval($_GET['deptid']);
$sql = "SELECT p.*,nom_cargo,nom_area,id_area,id_cargo from personal as p Inner Join cargos as c on p.cargo=c.id_cargo Inner join areas as ar ON p.area=ar.id_area WHERE id=:did";
$query = $dbh -> prepare($sql);
$query->bindParam(':did',$did,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  

         <div class="row">
        <div class="input-field col s6">
        <input id="txtdni" type="text"  class="validate" maxlength='8' pattern="[0-9]{8}" autocomplete="off" name="txtdni" value='<?php echo htmlentities($result->dno);?>'  required>
        <label for="txtdni">Numero DNI</label>
        </div>
        
        <div class="input-field col s6">
        <input id="txtfecn" type="date"  class="validate" autocomplete="off" name="txtfecn" value='<?php echo htmlentities($result->fechanac);?>' required>
        <label for="txtfecn"></label>
        </div>
       
        <div class="input-field col s6">
        <input id="txtaper" type="text"  class="validate" autocomplete="off" name="txtaper" value='<?php echo htmlentities($result->apellido);?>' required>
        <label for="txtaper">Apellidos</label>
        </div>
        <div class="input-field col s6">
        <input id="txtnper" type="text"  class="validate" autocomplete="off" name="txtnper" value='<?php echo htmlentities($result->nombre);?>' required>
        <label for="txtnper">Nombres</label>
        </div>

       
        <div class="input-field col s12">
        <input id="txtdir" type="text"  class="validate" autocomplete="off" name="txtdir"  value='<?php echo htmlentities($result->direccion);?>' required>
        <label for="txtdir">Direccion</label>
        </div>
        
       
        <div class="input-field col s6">
        <input id="txtciu" type="text"  class="validate" autocomplete="off" name="txtciu"  value='<?php echo htmlentities($result->ciudad);?>' required>
        <label for="txtciu">Ciudad</label>
        </div>
        
      
        <div class="input-field col s6">
        <select id='lstsexo' name='lstsexo' required>
        <option value='<?php echo htmlentities($result->sexo);?>'><?php echo htmlentities($result->sexo);?></option>
        <option value='M'>&raquo;Masculino</option>
        <option value='F'>&raquo;Femenino</option>
        <select>         
        <label for="txtnper">Sexo</label>
        </div>
        
   
        <div class="input-field col s6">
        <input id="txtemail" type="email"  class="validate" autocomplete="off" name="txtemail" value='<?php echo htmlentities($result->email);?>' required>
        <label for="txtemail">Email</label>
        </div>
         
        <div class="input-field col s6">
        <input id="txttel" type="text"  class="validate" autocomplete="off" name="txttel" value='<?php echo htmlentities($result->telefono);?>' required>
        <label for="txttel">Telefono</label>
        </div>
        
        <div class="input-field col s12"> </div>
        <div class="input-field col s6">
        <select id='lstcargo' name='lstcargo' required>
        <option value='<?php echo htmlentities($result->id_cargo);?>'><?php echo htmlentities($result->nom_cargo);?></option>
        <?php
         if($querycar->rowCount() > 0){
          foreach($resultscar as $resultsCar){   
         ?>
            <option value='<?php echo $resultsCar->id_cargo;?>'>&raquo; <?php echo htmlentities($resultsCar->nom_cargo);?></option>
         <?php 
          }
        }else{  ?> 
            <option value=''>No hay datos</option>
       <?php }    ?>
        </select>
        <label for="lstcargo">Cargo</label>
        </div>
        
        <div class="input-field col s6">
        <select id='lstarea' name='lstarea' required>
        <option value='<?php echo htmlentities($result->id_area);?>'><?php echo htmlentities($result->nom_area);?></option>
        
        <?php
         if($queryAr->rowCount() > 0){
          foreach($resultsAre as $resultsA){   
         ?>
            <option value='<?php echo $resultsA->id_area;?>'>&raquo; <?php echo htmlentities($resultsA->nom_area);?></option>
         <?php 
          }
        }else{  ?> 
            <option value=''>No hay datos</option>
       <?php }    ?>
        
        
        </select>
        <label for="lstarea">Area</label>
        </div>
        
        <div class="input-field col s12">
        <input id="txtbasico" type="text"  class="validate" autocomplete="off" name="txtbasico" value='<?php echo htmlentities($result->sueldo);?>' required>
        <label for="txtbasico">Sueldo Basico</label>
        </div>
        
        <div class="input-field col s6">
         <select id='lstsp' name='lstsp' required>
        <option value='<?php echo htmlentities($result->sistema);?>'><?php echo htmlentities($result->sistema);?></option>
         <option value='ONP'>&raquo;ONP</option>
         <option value='AFP'>&raquo;AFP</option>
        </select>
        <label for="lstsp">Sistema Pensionario</label>
        </div>
         <div class="input-field col s6">
        <input id="txtnumci" type="text"  class="validate" autocomplete="off" name="txtnumci" value='<?php echo htmlentities($result->numero);?>'>
        <label for="txtnumci">Numero</label>
        </div> 
           
           
           
           

<?php } } ?>


<div class="input-field col s12">
<a href='personal.php' class="waves-effect waves-red btn deep-orange m-b-xs"> Cancelar</a>

<button type="submit" name="update" class="waves-effect waves-light btn indigo m-b-xs">ACTUALIZAR</button>

</div>




                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                     
             
                   
                    </div>
                
                </div>
            </main>

        </div>
        <div class="left-sidebar-hover"></div>
        
        <!-- Javascripts -->
        <script src="../assets/plugins/jquery/jquery-2.2.0.min.js"></script>
        <script src="../assets/plugins/materialize/js/materialize.min.js"></script>
        <script src="../assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
        <script src="../assets/plugins/jquery-blockui/jquery.blockui.js"></script>
        <script src="../assets/js/alpha.min.js"></script>
        <script src="../assets/js/pages/form_elements.js"></script>
        
    </body>
</html>
<?php } ?> 
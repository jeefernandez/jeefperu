<?php
session_start();
error_reporting(0);
include('../includes/config.php');
if(strlen($_SESSION['emplogin'])==0){   
header('location:index.php');
}else{ 
if(isset($_POST['qhago'])){  


$did=intval($_POST['id']);  
$sql = "SELECT id,codigoper, dno, nombre, apellido from personal WHERE id=:did";
$query = $dbh -> prepare($sql);
$query->bindParam(':did',$did,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount()>0){
foreach($results as $result){  
   $nomper=htmlentities($result->apellido).', '.htmlentities($result->nombre);
 }
}
}
?>
<input type="hidden" id='idpersonal' value='<?php echo $result->id;?>'>

<table align="left">
<tr><td width="10px">
<b><i class="material-icons">person_outline</i></td><td><font style="text-transform: uppercase; color:#2880A5"> <?php echo $nomper;?></font></b>
</td></tr>
</table>
<br>
                      

 <?php }?>                     
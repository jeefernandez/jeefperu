<?php
session_start();
error_reporting(0);
include('../includes/config.php');
if(strlen($_SESSION['emplogin'])==0)
    {   
  header('location:index.php');
}else{ 


#obtener datos de planilla activos.
$tipopla=$_POST["lsttpl"];
$nperi=$_POST["lstper"];
$numes=$_POST["lstmes"];


#echo "es: $tipopla - $nperi - $numes";

#=== Validar Si PLANILLA ESTA ABIERTA

#llenar lista de descuentos
$sqldesto = "SELECT * from tipo_descuento where estado='1' order by 1 asc";
$querydsto = $dbh->prepare($sqldesto);
$querydsto->execute();
$resultsDsto=$querydsto->fetchAll(PDO::FETCH_OBJ);


#llenar lista de Bonificaciones
$sqlbonf = "SELECT * from tipo_bonificacion where estado='1' order by 1 asc";
$querybonf =$dbh->prepare($sqlbonf);
$querybonf->execute();
$resultsBonf=$querybonf->fetchAll(PDO::FETCH_OBJ);

#llenar lista de Tipo Planilla
$sqltp = "SELECT * from tipoplanilla where estado='1' order by 1";
$queryTP = $dbh->prepare($sqltp);
$queryTP->execute();
$resultsTP=$queryTP->fetchAll(PDO::FETCH_OBJ);

#llenar lista de Periodos
$sqlp = "SELECT * from periodo where estado='1' order by 1 limit 5";
$queryP = $dbh->prepare($sqlp);
$queryP->execute();
$resultsPer=$queryP->fetchAll(PDO::FETCH_OBJ);

?>
<!DOCTYPE html>
<html lang="en">
    <head>
<script>
function ver_data(){
 frm.submit();
}



function grabar_Datos(){
  var id=0;
  var idper=$('#idpersonal').val();
  var idsto=$('#lstdsto').val();
  var imp=$('#txtvalor').val();
  
 
  
  $.ajax({
    type: 'POST',
    url: 'vistalista_dsto.php', 
    data: 'id='+ id + '&qhago=INSERT' + '&idper='+idper + '&idsto='+idsto + '&imp='+imp,
    error: function(){
    alert("error petición ajax");
    },          
    success: function(resp){
    $('#listadsto').attr('disabled',false).html(resp);        
    //$('#listadsto').show();           
    }
    }); 
}
</script>
        
        <!-- Title -->
        <title>Admin | Generar Planilla</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />
        
        <!-- Styles -->
        <link type="text/css" rel="stylesheet" href="../assets/plugins/materialize/css/materialize.min.css"/>
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="../assets/plugins/material-preloader/css/materialPreloader.min.css" rel="stylesheet">
        <link href="../assets/plugins/datatables/css/jquery.dataTables.min.css" rel="stylesheet">

        <!-- https://materializecss.com/icons.html -->    
        <!-- Theme Styles -->
        <link href="../assets/css/alpha.min.css" rel="stylesheet" type="text/css"/>
        <link href="../assets/css/custom.css" rel="stylesheet" type="text/css"/>
<style>
        .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #E0B769;
    color:#fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 5px;
    margin: 0 0 20px 0;
    background: #5cb85c;
    color:#fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
        </style>
    </head>
    <body>
       <?php include('../includes/header.php');?>
            
       <?php include('../includes/sidebar.php');?>
            <main class="mn-inner">
                <div class="row">
                    <div class="col s12">
                        <div class="page-title">Gestión de Planilla [Elegir periodo y mes para generar la planilla]</div>
                    </div>
                   
<!--
<span class="card-title">
<div class="input-field col s12">
 <a href="addpersona.php?deptid=0">
 <button name="update" class="waves-effect waves-light btn indigo m-b-xs">AGREGAR</button>
 </a>
</div>
</span>

<?php if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
-->
<div class="col s12 m12 l12">
 
<div class="input-field col s12">

<div class="card">
<div class="card-content">

<form method='POST' name='frm' action="generarpla.php">
<table id="examples">
<tr>


<td>Planilla</td>
<td>
          <select id='lsttpl' name='lsttpl' required>
           <option value=''>...Elija</option>
           <?php
           if($queryTP->rowCount() > 0){
           foreach($resultsTP as $resultsTP){   
           ?>
      
       <option value="<?php echo $resultsTP->idtipoplanilla;?>"<?php if ($tipopla==$resultsTP->idtipoplanilla) echo " Selected"?>><?php echo $resultsTP->nameplanilla;?></option>
							
       <?php
          }
         }else{  ?> 
        <option value=''>No hay datos</option>
        <?php }    ?>
       </select>  
</td>


<td>Periodo</td>
<td>
          <select id='lstper' name='lstper' required>
           <option value=''>...Elija</option>
           <?php
           if($queryP->rowCount() > 0){
           foreach($resultsPer as $resultsPer){   
           ?>
          <option value="<?php echo $resultsPer->idperiodo;?>"<?php if ($nperi==$resultsPer->idperiodo) echo " Selected"?>><?php echo $resultsPer->nameperiodo;?></option>
          <?php 
          }
         }else{  ?> 
        <option value=''>No hay datos</option>
        <?php }    ?>
       </select>  
</td>
<th>Mes</th>
<td>
 <select id="lstmes" name='lstmes' onchange='ver_data();'>
  <option value=''>Elija</option>

  <option value='01'<?php if ($numes=='01') echo " Selected"?>>&raquo;Enero</option>
  <option value='02'<?php if ($numes=='02') echo " Selected"?>>&raquo;Febrero</option>
  <option value='03'<?php if ($numes=='03') echo " Selected"?>>&raquo;Marzo</option>
  <option value='04'<?php if ($numes=='04') echo " Selected"?>>&raquo;Abril</option>
  <option value='05'<?php if ($numes=='05') echo " Selected"?>>&raquo;Mayo</option>
  <option value='06'<?php if ($numes=='06') echo " Selected"?>>&raquo;Junio</option>
  <option value='07'<?php if ($numes=='07') echo " Selected"?>>&raquo;Julio</option>
  <option value='08'<?php if ($numes=='08') echo " Selected"?>>&raquo;Agosto</option>
  <option value='09'<?php if ($numes=='09') echo " Selected"?>>&raquo;Septiembre</option>
  <option value='10'<?php if ($numes=='10') echo " Selected"?>>&raquo;Octubre</option>
  <option value='11'<?php if ($numes=='11') echo " Selected"?>>&raquo;Noviembre</option>
  <option value='21'<?php if ($numes=='12') echo " Selected"?>>&raquo;Diciembre</option>
 </select>
</td>
<td></td>
<td>
<a href='xls_gp.php?tp=<?php echo $tipopla;?>&np=<?php echo $nperi;?>&nm=<?php echo $numes;?>' class="waves-effect waves-red btn deep-orange m-b-xs"> Exportar Planilla</a></td>

</tr>
</table>

</form>  
  

<table>
<thead>
<tr style="background-color: #D4D9FA; border: 1px solid #3797E0;">
<th rowspan="2">Código </th>
<th rowspan="2">Apellidos y Nombres</th>
<th rowspan="2">Area/Cargo</th>
<th rowspan="2">Basico</th>
<th style='text-align:center;'>Descuentos</th>
<th style='text-align:center;'>Bonificaciones</th>
<th rowspan="2">Total Dsto</th>
<th rowspan="2">Total Bonif</th>
<th rowspan="2">Sueldo Neto</th>
</tr>
<tr>
<td>
  <table style="background-color: #FFD9FA;"><tr> 
          <?php
           foreach($resultsDsto as $resultsDsto){   
           ?>
           <td width="40px"><?php echo $resultsDsto->nombrecorto;?></td>
          <?php 
          }
          ?>
  </tr>
  </table>
</td>
<td>
  <table style="border-color: #92a8d1;border-width: 2px;background-color: #E1F9F5;"><tr> 
          <?php
           foreach($resultsBonf as $resultsBonf){   
           ?>
           <td width="40px"><?php echo $resultsBonf->namecorto;?></td>
          <?php 
          }
          ?>  
  </tr>
  </table>
</td>

    


</tr>
</thead>
<tbody>                                
<?php 
  /*$sql = "select idplanilla, fecha, hora, idtipoplanilla, idperiodo, idmes, idtrabajador, sueldo, total_dscto, 
	total_bonf, netopagar, estadoplanilla, pl.estado, pr.id, codigoper, dno, nombre, apellido from planilla as pl INNER JOIN personal as pr ON
  pl.idtrabajador=pr.id where idperiodo='' and idmes='' and idtipoplanilla='' and estado='1' order by 1";*/

$sql = "SELECT p.*,nom_cargo,nom_area from personal as p Inner Join cargos as c on p.cargo=c.id_cargo Inner join areas as ar On
p.area=ar.id_area where p.estado='1' order by apellido asc"; 
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0){
foreach($results as $result){               ?>  
         <tr style='border-bottom: 1px solid #3797E0;'>
        <td><?php echo htmlentities($result->codigoper);?></td>
        <td>
         <?php
                if($result->sexo=='M'){
                ?>
                <img src='../assets/images/boy.png' width='20px'>
                <?php  
                 }else{
               ?>
                <img src='../assets/images/girl.png' width='20px'>       
                <?php  
               }
              ?>
             <?php echo htmlentities($result->apellido);?>, <?php echo htmlentities($result->nombre);?>
         <br>DNI:  <?php echo htmlentities($result->dno);?></td>
        <td><?php echo $result->nom_cargo;?> <br> <?php echo $result->nom_area;?></td>                                 
      
        <td style='text-align:right'>
        <?php 
        $nb=number_format($result->sueldo,2);
        echo $nb;
        ?>
        </td>
        <td>
        <!-- Descuentos -->
          <table>
          <tr>
          <?php
          $basico=$result->sueldo;
          $idpersona=$result->id;
          $ttdsto=0;
          $sql1 = "SELECT * from tipo_descuento where estado='1' order by 1 asc";
          $query1 = $dbh->prepare($sql1);
          $query1->execute();
          $results1=$query1->fetchAll(PDO::FETCH_OBJ);
          foreach($results1 as $results1){   
          
          $idtdstper=$results1->iddescuento;
          $sqld = "SELECT idtdsto, valor_dscto from descuento_personal as dp where id_personal='$idpersona' 
          and id_planilla='$tipopla' and id_periodo='$nperi' and nummes='$numes' and id_tipo_dscto='$idtdstper' 
          and dp.estado='1'";
          $querydp = $dbh->prepare($sqld);
          $querydp->execute();
          $resultsDp=$querydp->fetchAll(PDO::FETCH_OBJ);
           
           if($querydp->rowCount() > 0){
             foreach($resultsDp as $resultsDp){   
             $ttdsto=$ttdsto+$resultsDp->valor_dscto;
             ?>
             <td style="background-color: #FFD9FA;width:30px;"><?php echo $resultsDp->valor_dscto;?></td>
            <?php 
            }
          }else{
          ?>
           <td style='text-align:center;background-color: #FFD9FA;width:30px;'>0.00</td>
        <?php
          }
        }
          ?>
          </tr></table>
       </td> 
       <td>  
       <!-- Bonificaciones -->   
       <table>
       <tr>  
         <?php
          $ttbinf=0;
          $sql2= "SELECT * from tipo_bonificacion where estado='1' order by 1 asc";
          $query2 = $dbh->prepare($sql2);
          $query2->execute();
          $results2=$query2->fetchAll(PDO::FETCH_OBJ);
          foreach($results2 as $results2){   
          
          $idtbonfper=$results2->idbonificacion;
          $sqlb = "SELECT idbonfi, valor_bonfi from bonificacion_personal as dp where idpersonal='$idpersona' 
          and idplanilla='$tipopla' and idperiodo='$nperi' and nummes='$numes' and id_tipo_bonifi='$idtbonfper' 
          and dp.estado='1'";
          $querybp = $dbh->prepare($sqlb);
          $querybp->execute();
          $resultsBp=$querybp->fetchAll(PDO::FETCH_OBJ);
           
           if($querybp->rowCount() > 0){
             foreach($resultsBp as $resultsBp){   
             $ttbinf=$ttbinf+$resultsBp->valor_bonfi;
             ?>
             <td style="background-color: #DCFFFA;width:30px;"><?php echo $resultsBp->valor_bonfi;?></td>
            <?php 
            }
          }else{
           ?>
           <td style='text-align:center;background-color: #DCFFFA;width:30px;'>0.00</td>
        <?php
          }
        }         
       ?>
       </tr>
       </table>
      <?php 
      $sueldoneto= ($basico-$ttdsto)+$ttbinf; 
      
      $td=number_format($ttdsto,2);
      $tb=number_format($ttdsto,2);
      $sn=number_format($sueldoneto,2);
      
      
      ?> 
       </td>
       <td style='text-align:right'><?php echo $td;?>&nbsp;</td>
       <td style='text-align:right'><?php echo $tb;?>&nbsp;</td>
       <td style='text-align:right'><?php echo $sn;?>&nbsp;</td>
      
    </tr>
    <?php $cnt++;} }?>
   </tbody>
   </table>
  
                   
</div>

</div>
                                
</div>
                            
                            
             
                    </div>
                </div>
            </main>
         
        </div>
        <div class="left-sidebar-hover"></div>
        
        <!-- Javascripts -->
        <script src="../assets/plugins/jquery/jquery-2.2.0.min.js"></script>
        <script src="../assets/plugins/materialize/js/materialize.min.js"></script>
        <script src="../assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
        <script src="../assets/plugins/jquery-blockui/jquery.blockui.js"></script>
        <script src="../assets/plugins/datatables/js/jquery.dataTables.min.js"></script>
        <script src="../assets/js/alpha.min.js"></script>
        <script src="../assets/js/pages/table-data.js"></script>
        
        
    </body>
</html>
<?php } ?>

<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					});
		   </script>
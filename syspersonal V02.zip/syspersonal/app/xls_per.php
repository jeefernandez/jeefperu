<?php
session_start();
error_reporting(0);
include('../includes/config.php');
if(strlen($_SESSION['emplogin'])==0)
    {   
header('location:index.php');
}
else{ 

  header("Content-type: application/vnd.ms-excel");
  #header("Content-type:application/pdf");
  header("Content-Disposition: attachment; filename=Listado_Personal_".date('Y').".xls");
  header("Pragma: no-cache");                                                             
  header("Expires: 0");
  
    ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        
        <!-- Title -->
        <title>Admin | Reporte de Personal</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />
        
      

    </head>
    <body>
      
            <main class="mn-inner">
                <div class="row">
                   
                    <div class="col s12 m12 l12">
                        <div class="card">
                            <div class="card-content">


 <table id="example" class="display responsive-table" >
 <tr><td colspan='14' align='center'><font size='8' color='green'>REPORTE DE PERSONAL <?php echo date('Y');?></td></tr>
 <tr><td colspan='14' align='left'>Fecha: <?php echo date('d-m-Y');?></td></tr>                             
 </table>
 
 <table border='1px'>
  <thead>
                                        <tr bgcolor='#AEEEB8'>
                                            <th>Id </th>
                                            <th>Codigo</th>
                                            <th>DNI</th>
                                            <th>Apellidos y Nombres</th>
                                            <th>Dirección</th>
                                            <th>Ciudad</th>
                                            <th>Email</th>
                                            <th>Telefono</th>
                                            <th>Fecha Nac.</th>
                                            <th>Area</th>
                                            <th>Cargo</th>
                                            <th>Fecha Ing.</th>
                                            <th>Sistea</th>
                                            <th>Basico</th>
                                        </tr>
                                    </thead>
                                 
                                    <tbody>                                
<?php $sql = "SELECT p.*,nom_cargo,nom_area from personal as p Inner Join cargos as c on p.cargo=c.id_cargo INNER JOIN areas ON p.area=id_area";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  
                                        <tr>
                                            <!-- <td><?php #echo htmlentities($cnt);?></td> -->
                                            <td><?php echo htmlentities($result->id);?></td>
                                            <td><?php echo htmlentities($result->codigoper);?></td>
                                            <td><?php echo htmlentities($result->dno);?></td>
                                            <td><?php echo htmlentities($result->apellido);?>, <?php echo htmlentities($result->nombre);?></td>
                                            <td><?php echo htmlentities($result->direccion);?></td>
                                            <td><?php echo htmlentities($result->ciudad);?></td>
                                            <td><?php echo htmlentities($result->email);?></td> 
                                            <td><?php echo htmlentities($result->telefono);?></td>
                                            <td><?php echo htmlentities($result->fechanac);?></td>
                                            <td><?php echo htmlentities($result->nom_area);?></td>
                                            <td><?php echo htmlentities($result->nom_cargo);?></td>
                                            <td><?php echo htmlentities($result->fecIngreso);?></td>
                                            <td><?php echo htmlentities($result->sistema);?></td>
                                            <td><?php echo htmlentities($result->sueldo);?></td>
                                           
                                        </tr>
                                         <?php $cnt++;} }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
         
        </div>
      
        
    </body>
</html>
<?php } ?>



<?php
session_start();
error_reporting(0);
include('../includes/config.php');
if(strlen($_SESSION['emplogin'])==0){   
header('location:index.php');
}else{ 

$dat=$_POST["dper"];
?>
 <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />
        
<table>
<tr>
<th>C&oacute;digo </th>
<th>Apellidos y Nombres</th>
<th></th>
</tr>
</thead>
<tbody>                                
<?php $sql = "SELECT p.*,nom_cargo from personal as p Inner Join cargos as c on p.cargo=c.id_cargo where apellido like '$dat%' or dno like '$dat%' limit 20";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  
         <tr>
                                            
        <td><?php echo htmlentities($result->id);?></td>
        <td>
         <?php
                if($result->sexo=='M'){
                ?>
                <img src='../assets/images/boy.png' width='20px'>
                <?php  
                 }else{
               ?>
                <img src='../assets/images/girl.png' width='20px'>       
                <?php  
               }
              ?>
             <?php echo htmlentities($result->apellido);?>, <?php echo htmlentities($result->nombre);?>
         <br>DNI:  <?php echo htmlentities($result->dno);?></td>
                                         
    <td><a href="#">
    <i class="material-icons" onclick="verdetalle('<?php echo htmlentities($result->id);?>');">more_vert</i></a>
    </td>
    </tr>
    <?php $cnt++;} }?>
   </tbody>
   </table>
<?php } ?>
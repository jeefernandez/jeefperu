<?php
session_start();
error_reporting(0);
include('../includes/config.php');
if(strlen($_SESSION['emplogin'])==0)
    {   
header('location:index.php');
}
else{ 
if(isset($_GET['del']))
{
$id=$_GET['del'];
$sql = "delete from  personal  WHERE id=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();
$msg="Registro de Persona eliminado";

}

#llenar lista de descuentos
$sqldesto = "SELECT * from tipo_descuento where estado='1'";
$querydsto = $dbh -> prepare($sqldesto);
$querydsto->execute();
$resultsDsto=$querydsto->fetchAll(PDO::FETCH_OBJ);

#== Obtener id de Planilla Activa / Abierta.

$sqltp = "SELECT cp.*,tp.nameplanilla,pr.nameperiodo from configurar_planilla as cp INNER JOIN tipoplanilla as tp on cp.idtipopla=tp.idtipoplanilla
Inner Join periodo as pr ON cp.idperiodo=pr.idperiodo where cp.estado='1' order by 1 limit 1";
$queryTP = $dbh->prepare($sqltp);
$queryTP->execute();
$resultsTP=$queryTP->fetchAll(PDO::FETCH_OBJ);
if($queryTP->rowCount()>0){
 $ac=1;
 $nplac="<font color='blue'>Planilla Activa</font>";
 $colorpla='#A5E882';
}else{
 $ac=0;
 $nplac="<font color='red'>Debe de Aperturar Planilla</font>";
 $colorpla='#F7D4BC';
}


?>
<!DOCTYPE html>
<html lang="en">
    <head>
<script>
function verdetalle(id)
{
    $.ajax({
    type: 'POST',
    url: 'vistadata_dsto.php', 
    data: 'id='+ id + '&qhago=VIEW',
    beforeSend: function(){
    //imagen de carga        
    $('#viewdato').prepend("<div style='position:absolute;float:fixed;left:20%;top:27%;z-index:25;'><img src='../assets/images/loader_cicle.gif' /></div>");
    },
    error: function(){
    alert("error petición ajax");
    },          
    success: function(resp){        
    $('#viewdato').attr('disabled',false).html(resp);
    $('#addform').show();           
    }
    }); 
    
  
    $.ajax({
    type: 'POST',
    url: 'vistalista_dsto.php', 
    data: 'id='+ id + '&qhago=VIEW',
    error: function(){
    alert("error petición ajax");
    },          
    success: function(resp){
    $('#listadsto').attr('disabled',false).html(resp);        
    $('#listadsto').show();  
           
    }
    }); 

}

function grabar_Datos(){
  
  var idper=$('#idpersonal').val();
  var idsto=$('#lstdsto').val();
  var imp=$('#txtvalor').val();
  var add="INSERT";
  var id=idper;
  
  $.ajax({
    type: 'POST',
    url: 'vistalista_dsto.php', 
    data: 'id='+ id + '&add='+add + '&idper='+idper + '&idsto='+idsto + '&imp='+imp,
    error: function(){
    alert("error petición ajax");
    },          
    success: function(resp){
    $('#listadsto').attr('disabled',false).html(resp);        
    //$('#listadsto').show(); 
      
    }
    }); 

    $('#lstdsto').val('Elija');
    $('#txtvalor').val(''); 
}

function eliminar(id,idper){
    
    var c= confirm('Estas seguro de eliminar?'); 
    if(c==true){

      $.ajax({
      type: 'POST',
      url: 'vistalista_dsto.php', 
      data: 'id='+ idper + '&del='+id,
      error: function(){
      alert("error petición ajax");
      },          
      success: function(resp){
      $('#listadsto').attr('disabled',false).html(resp);  
       //alert(resp);      
      }
      }); 
    }else{
     return false;
    }
}

function buscar_datos(){
 var dper=$('#busper').val();
 $.ajax({
      type: 'POST',
      url: 'dat_persona.php', 
      data: 'dper='+ dper ,
      error: function(){
      alert("error petición ajax");
      },          
      success: function(resp){
      $('#viewdata').attr('disabled',false).html(resp);  
       //alert(resp);      
      }
      });

}
</script>
        
        <!-- Title -->
        <title>Admin | Administrar Descuentos</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />
        
        <!-- Styles -->
        <link type="text/css" rel="stylesheet" href="../assets/plugins/materialize/css/materialize.min.css"/>
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="../assets/plugins/material-preloader/css/materialPreloader.min.css" rel="stylesheet">
        <link href="../assets/plugins/datatables/css/jquery.dataTables.min.css" rel="stylesheet">

        <!-- https://materializecss.com/icons.html -->    
        <!-- Theme Styles -->
        <link href="../assets/css/alpha.min.css" rel="stylesheet" type="text/css"/>
        <link href="../assets/css/custom.css" rel="stylesheet" type="text/css"/>
<style>
        .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #E0B769;
    color:#fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 5px;
    margin: 0 0 20px 0;
    background: #5cb85c;
    color:#fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
        </style>
    </head>
    <body>
       <?php include('../includes/header.php');?>
            
       <?php include('../includes/sidebar.php');?>
            <main class="mn-inner">
                <div class="row">
                    <div class="col s12">
                        <div class="page-title">Gestión de Descuentos</div>
                    </div>
                   
<!--
<span class="card-title">
<div class="input-field col s12">
 <a href="addpersona.php?deptid=0">
 <button name="update" class="waves-effect waves-light btn indigo m-b-xs">AGREGAR</button>
 </a>
</div>
</span>

<?php if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
-->
<div class="col s12 m12 l12">
 
<div class="input-field col s6">

<div class="card">
<div class="card-content">

<div class="input-field col s12">
   Busqueda rapida  <input type="text" name='busper' id="busper" onkeyup='buscar_datos();' placeholder="[DNI Apellidos y Nombres]">
</div>

<div id='viewdata'>
<table>
<tr>
<th>Código </th>
<th>Apellidos y Nombres</th>
<th></th>
</tr>
</thead>
<tbody>                                
<?php $sql = "SELECT p.*,nom_cargo from personal as p Inner Join cargos as c on p.cargo=c.id_cargo limit 20";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  
         <tr>
                                            
        <td><?php echo htmlentities($result->id);?></td>
        <td>
         <?php
                if($result->sexo=='M'){
                ?>
                <img src='../assets/images/boy.png' width='20px'>
                <?php  
                 }else{
               ?>
                <img src='../assets/images/girl.png' width='20px'>       
                <?php  
               }
              ?>
             <?php echo htmlentities($result->apellido);?>, <?php echo htmlentities($result->nombre);?>
         <br>DNI:  <?php echo htmlentities($result->dno);?></td>
                                         
    <td><a href="#">
    <i class="material-icons" onclick="verdetalle('<?php echo htmlentities($result->id);?>');">more_vert</i></a>
    </td>
    </tr>
    <?php $cnt++;} }?>
   </tbody>
   </table>
  </div>
                   
</div>

</div>
                                
</div>
                            
                            
               <div class="input-field col s6">

                <div class="card">
                <div class="card-content">                
                   Asignar Descuentos al personal            
                <div id="frmdsto">
                <div class="row">
                   <div id="addform" style="display:none;"> 
                    <!-- <form class="col s12" name="adperiodo" method="post"> -->
                     <div class="input-field col s12">
                      <select id='lstdsto' name='lstdsto' required>
                      <option value='Elija'>...Elija</option>
                      <?php
                       if($querydsto->rowCount() > 0){
                        foreach($resultsDsto as $resultsDto){   
                       ?>
                          <option value='<?php echo $resultsDto->iddescuento;?>'>&raquo; <?php echo htmlentities($resultsDto->namedescuento);?></option>
                       <?php 
                        }
                      }else{  ?> 
                          <option value=''>No hay datos</option>
                     <?php }    ?>
                      </select>
                      <label for="txtnper">Tipo Descuento </label>
                       </div>
                       
                      <div class="input-field col s6">
                      <input id="txtvalor" type="number" step="0.01"  class="validate" autocomplete="off" name="txtvalor"  required>
                      <label for="txtdni">Importe</label>
                      </div>
                      <div class="input-field col s6">
                      <?php if($ac=='1'){?>
                      <button onclick="grabar_Datos();" name="update" class="waves-effect waves-light btn indigo m-b-xs">Agregar</button>
                      <?php }else{ ?>
                             <font color='red'><i class="material-icons">error</i></font>
                             <font color='red'>Planilla Inactiva, debe activar para agregar</font>
                      <?php } ?>
                      </div>
                     <!-- </form> -->   
                    </div>  
                </div> 
                <div id="viewdato"><!-- Aqui nombre del trabajador --></div>
                <div id="listadsto" style="display:none;">
                    <!-- Aqui detalle de descuentos por personal -->
                </div>
                </div>
                </div>
              </div>
                            
                            
      <!---- -->                      
                        </div>
                    </div>
                </div>
            </main>
         
        </div>
        <div class="left-sidebar-hover"></div>
        
        <!-- Javascripts -->
        <script src="../assets/plugins/jquery/jquery-2.2.0.min.js"></script>
        <script src="../assets/plugins/materialize/js/materialize.min.js"></script>
        <script src="../assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
        <script src="../assets/plugins/jquery-blockui/jquery.blockui.js"></script>
        <script src="../assets/plugins/datatables/js/jquery.dataTables.min.js"></script>
        <script src="../assets/js/alpha.min.js"></script>
        <script src="../assets/js/pages/table-data.js"></script>
        
        
    </body>
</html>
<?php } ?>

<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					});
		   </script>
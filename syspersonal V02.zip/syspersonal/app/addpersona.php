<?php
session_start();
error_reporting(0);
if(strlen($_SESSION['emplogin'])==0){   
header('location:index.php');
}else{
	
include('../includes/config.php');
include('../includes/funciones.php');

if(isset($_POST['update'])){
	#Recibimos variables del formulario
	$id=getCodigo($dbh,'personal','id'); # Obtenemos el codigo del nuevo registro
	$ndni=$_POST['txtdni'];
	$fecn=$_POST['txtfecn'];
	$ape=$_POST['txtaper'];
	$nom=$_POST['txtnper'];
	$dir=$_POST['txtdir'];
	$ciu=$_POST['txtciu'];
	$sexo=$_POST['lstsexo'];
	$email=$_POST['txtemail'];
	$tel=$_POST['txttel'];
	$idcar=$_POST['lstcargo'];
	$idar=$_POST['lstarea'];
	$basico=$_POST['txtbasico'];
	$sp=$_POST['lstsp'];
	$nci=$_POST['txtnumci'];
	$estado=1;
	$pass=''; #campo contraseña en blanco  para que no tenga permisos
	$fecing=date('Y-m-d');
	$corr=sprintf("%'.04d", $id);
	$numper = "E".date("y")."-".$corr;
	$tipouser='0'; # 0 sin acceso y 1 personal con acceso al sistema

$sql="INSERT INTO personal(id, codigoper, dno, nombre, apellido, email, Passwordp, sexo, fechanac, 
	direccion, ciudad, pais, telefono, area, cargo, sueldo, estado, fecIngreso, 
	sistema, numero,tipouser) VALUES ('$id','$numper','$ndni','$nom','$ape','$email','','$sexo','$fecn','$dir',
  '$ciu','','$tel','$idar','$idcar','$basico','$estado','$fecing','$sp','$nci','$tipouser')";
$query = $dbh->prepare($sql);
$query->execute();

$msg="Registro de Personal con exito";
header('location:personal.php');
}
                     
$sqlcargo = "SELECT * from cargos where est_cargo='1'";
$querycar = $dbh -> prepare($sqlcargo);
$querycar->execute();
$resultscar=$querycar->fetchAll(PDO::FETCH_OBJ);

$sqlArea = "SELECT * from areas where est_area='1'";
$queryAr = $dbh -> prepare($sqlArea);
$queryAr->execute();
$resultsAre=$queryAr->fetchAll(PDO::FETCH_OBJ);
?>

<!DOCTYPE html>
<html lang="en">
    <head>        
        <!-- Title -->
        <title>Admin | Personal  actualización</title>        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />        
        <!-- Styles -->
        <link type="text/css" rel="stylesheet" href="../assets/plugins/materialize/css/materialize.min.css"/>
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="../assets/plugins/material-preloader/css/materialPreloader.min.css" rel="stylesheet"> 
        <link href="../assets/css/alpha.min.css" rel="stylesheet" type="text/css"/>
        <link href="../assets/css/custom.css" rel="stylesheet" type="text/css"/>
<style>
   .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #5cb85c ;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
</style>
</head>

<body>
  <?php include('../includes/header.php');?>
  <?php include('../includes/sidebar.php');?>
  <main class="mn-inner">
  <div class="row">
  <div class="col s12">
   <div class="page-title">Actualización de Personal</div>
  </div>
  <div class="col s12 m12 l6">
  <div class="card">
  <div class="card-content">
                              
<div class="row">
<form class="col s12" name="adperiodo" method="post">
<?php if($error){?>
<div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div>
<?php } 
 else if($msg){?>
 <div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div>
 <?php }?>
        
    <div class="row">
    <div class="input-field col s6">
    <input id="txtdni" type="text" maxlength='8' pattern="[0-9]{8}"  class="validate" autocomplete="off" name="txtdni" required>
    <label for="txtdni">Numero DNI</label>
    </div>       
        
    <div class="input-field col s6">        
    <input placeholder="" id="txtfecn" name="txtfecn" class="masked" type="text" data-inputmask="'alias': 'date'" required>
    <label for="fromdate">Fecha nacimiento</label>
    </div>        
      
    <div class="input-field col s6">
    <input id="txtaper" type="text"  class="validate" autocomplete="off" name="txtaper"  required>
    <label for="txtaper">Apellidos</label>
    </div>
    <div class="input-field col s6">
    <input id="txtnper" type="text"  class="validate" autocomplete="off" name="txtnper"  required>
    <label for="txtnper">Nombres</label>
    </div>
       
    <div class="input-field col s12">
    <input id="txtdir" type="text"  class="validate" autocomplete="off" name="txtdir"  required>
    <label for="txtdir">Direccion</label>
    </div>
       
    <div class="input-field col s6">
    <input id="txtciu" type="text"  class="validate" autocomplete="off" name="txtciu"  required>
    <label for="txtciu">Ciudad</label>
    </div>        
      
    <div class="input-field col s6">
    <select id='lstsexo' name='lstsexo' required>
    <option value=''>...Elija</option>
    <option value='M'>&raquo;Masculino</option>
    <option value='F'>&raquo;Femenino</option>
    <select>         
    <label for="txtnper">Sexo</label>
    </div>        
   
    <div class="input-field col s6">
    <input id="txtemail" type="email"  class="validate" autocomplete="off" name="txtemail"  required>
    <label for="txtemail">Email</label>
    </div>
         
    <div class="input-field col s6">
    <input id="txttel" type="text"  class="validate" autocomplete="off" name="txttel"  required>
    <label for="txttel">Telefono</label>
    </div>        
  
    <div class="input-field col s6">
    <select id='lstcargo' name='lstcargo' required>
    <option value=''>...Elija</option>
    <?php
       if($querycar->rowCount() > 0){
        foreach($resultscar as $resultsCar){   
    ?>
        <option value='<?php echo $resultsCar->id_cargo;?>'>&raquo; <?php echo htmlentities($resultsCar->nom_cargo);?></option>
    <?php } #cerramos el foreach
        }else{ #si no hay datos ?> 
            <option value=''>No hay datos</option>
    <?php }    ?>
    </select>	
    <label for="lstcargo">Cargo</label>	
    </div> 
	
        <div class="input-field col s6">
        <select id='lstarea' name='lstarea' required>
        <option value=''>...Elija</option>        
        <?php
         if($queryAr->rowCount() > 0){
          foreach($resultsAre as $resultsA){   
         ?>
            <option value='<?php echo $resultsA->id_area;?>'>&raquo; <?php echo htmlentities($resultsA->nom_area);?></option>
         <?php 
          }
        }else{  ?> 
            <option value=''>No hay datos</option>
       <?php }    ?>
        </select>
        <label for="lstarea">Area</label>
        </div>
        
        <div class="input-field col s12">
        <input id="txtbasico" type="text"  class="validate" autocomplete="off" name="txtbasico"  required>
        <label for="txtbasico">Sueldo Basico</label>
        </div>
        
        <div class="input-field col s6">
         <select id='lstsp' name='lstsp' required>
        <option value=''>...Elija</option>
         <option value='ONP'>&raquo;ONP</option>
         <option value='AFP'>&raquo;AFP</option>
        </select>
        <label for="lstsp">Sistema Pensionario</label>
        </div>
         <div class="input-field col s6">
        <input id="txtnumci" type="text"  class="validate" autocomplete="off" name="txtnumci" >
        <label for="txtnumci">Numero</label>
        </div>


<div class="input-field col s12">
<a href='personal.php' class="waves-effect waves-red btn deep-orange m-b-xs"> Cancelar</a>
<button type="submit" name="update" class="waves-effect waves-light btn indigo m-b-xs">Guardar</button>

</div></div>                                       
 </form>
 
 </div>                                
</div>
   </div>
   </div>
  </div>
  </main>

</div>
<div class="left-sidebar-hover"></div>
        
        <!-- Javascripts -->
        <script src="../assets/plugins/jquery/jquery-2.2.0.min.js"></script>
        <script src="../assets/plugins/materialize/js/materialize.min.js"></script>
        <script src="../assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
        <script src="../assets/plugins/jquery-blockui/jquery.blockui.js"></script>
        <script src="../assets/js/alpha.min.js"></script>
        <script src="../assets/js/pages/form_elements.js"></script>        
        <script src="assets/js/pages/form-input-mask.js"></script>
        <script src="assets/plugins/jquery-inputmask/jquery.inputmask.bundle.js"></script>
                
        <script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					});
		   </script>
    
        
    </body>
</html>
<?php } ?> 
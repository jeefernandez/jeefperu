<?php
session_start();
error_reporting(0);
include('../includes/config.php');
if(strlen($_SESSION['emplogin'])==0)
    {   
  header('location:index.php');
}else{ 


#obtener datos de planilla activos.
$tipopla=$_GET["tp"];
$nperi=$_GET["np"];
$numes=$_GET["nm"];


#echo "es: $tipopla - $nperi - $numes";

#=== Validar Si PLANILLA ESTA ABIERTA
#llenar lista de descuentos
$sqldesto = "SELECT * from tipo_descuento where estado='1' order by 1 asc";
$querydsto = $dbh->prepare($sqldesto);
$querydsto->execute();
$resultsDsto=$querydsto->fetchAll(PDO::FETCH_OBJ);


#llenar lista de Bonificaciones
$sqlbonf = "SELECT * from tipo_bonificacion where estado='1' order by 1 asc";
$querybonf =$dbh->prepare($sqlbonf);
$querybonf->execute();
$resultsBonf=$querybonf->fetchAll(PDO::FETCH_OBJ);

#llenar lista de Periodos
$sqltp = "SELECT * from tipoplanilla where estado='1' and idtipoplanilla='$tipopla' order by 1";
$queryTP = $dbh->prepare($sqltp);
$queryTP->execute();
$resultsTP=$queryTP->fetchAll(PDO::FETCH_OBJ);

#llenar lista de Periodos
$sqlp = "SELECT * from periodo where estado='1' and idperiodo='$nperi' order by 1";
$queryP = $dbh->prepare($sqlp);
$queryP->execute();
$resultsPer=$queryP->fetchAll(PDO::FETCH_OBJ);

foreach($resultsTP as $resultsTP){ 
   $ntplanilla=$resultsTP->nameplanilla;
  }
 foreach($resultsPer as $resultsPer){   
  $nperiodo=$resultsPer->nameperiodo;
 }
          
 if($numes=='01') $nmes='Enero';
 if($numes=='02') $nmes='Febero';
 if($numes=='03') $nmes='Marzo';
 if($numes=='04') $nmes='Abril';
 if($numes=='05') $nmes='Mayo';
 if($numes=='06') $nmes='Junio';
 if($numes=='07') $nmes='Julio';
 if($numes=='08') $nmes='Agosto';
 if($numes=='09') $nmes='Septiembre';
 if($numes=='10') $nmes='Octubre';
 if($numes=='11') $nmes='Noviembre';
 if($numes=='12') $nmes='Diciembre';
 
  header("Content-type: application/vnd.ms-excel");
  header("Content-Disposition: attachment; filename=Planilla_".$ntplanilla.'-'.$nperiodo.'-'.substr($nmes,0,3).".xls");
  header("Pragma: no-cache");                                                             
  header("Expires: 0");


?>
<!DOCTYPE html>
<html lang="en">
    <head>
  
        <!-- Title -->
        <title>Admin | Generar Planilla</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />


<main class="mn-inner">
<div class="row">
<div class="col s12 m12 l12">
<div class="input-field col s12">
<div class="card">
<div class="card-content">


<table>
<tr><td colspan='14' style='text-align:center;'><font size='8pt' color='blue'><b>PLANILLA DE PERSONAL <?php echo $nperiodo;?></b></td></tr>
<tr>
<td><b>Fecha:</b></td><td><?php echo date('d-m-Y');?></td>
<td><b>Tipo Planilla</b></td><td><?php echo $ntplanilla?></td>
<td><b>Periodo</b></td><td colspan='4'> <?php echo $nperiodo?> - <?php echo $nmes;?></td>
</tr>
</table>

<table border='1px' style='border: 1px solid #A4BBC7;'>
<thead>
<tr style="background-color: #D4D9FA;">
<th rowspan="2">CODIGO </th>
<th rowspan="2">DNI </th>
<th rowspan="2">TRABAJADOR</th>
<th rowspan="2">AREA/CARGO</th>
<th rowspan="2">BASICO</th>
<th style='text-align:center;'>DESCUENTOS</th>
<th style='text-align:center;'>BONIFICACIONES</th>
<th rowspan="2">TOTAL DSTO</th>
<th rowspan="2">TOTAL BONIF</th>
<th rowspan="2">SUELDO NETO</th>
</tr>
<tr>
<td>
  <table style="background-color: #FFD9FA;"><tr> 
          <?php
           foreach($resultsDsto as $resultsDsto){   
           ?>
           <td width="40px"><?php echo $resultsDsto->nombrecorto;?></td>
          <?php 
          }
          ?>
  </tr>
  </table>
</td>
<td>
  <table style="border-color: #92a8d1;border-width: 1px;background-color: #E1F9F5;"><tr> 
          <?php
           foreach($resultsBonf as $resultsBonf){   
           ?>
           <td width="40px"><?php echo $resultsBonf->namecorto;?></td>
          <?php 
          }
          ?>  
  </tr>
  </table>
</td>

    


</tr>
</thead>
<tbody>                                
<?php 
  /*$sql = "select idplanilla, fecha, hora, idtipoplanilla, idperiodo, idmes, idtrabajador, sueldo, total_dscto, 
	total_bonf, netopagar, estadoplanilla, pl.estado, pr.id, codigoper, dno, nombre, apellido from planilla as pl INNER JOIN personal as pr ON
  pl.idtrabajador=pr.id where idperiodo='' and idmes='' and idtipoplanilla='' and estado='1' order by 1";*/

$sql = "SELECT p.*,nom_cargo,nom_area from personal as p Inner Join cargos as c on p.cargo=c.id_cargo Inner join areas as ar On
p.area=ar.id_area where p.estado='1' order by apellido asc"; 
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0){
foreach($results as $result){               ?>  
         <tr>
        <td><?php echo htmlentities($result->codigoper);?></td>
        <td> <?php echo htmlentities($result->dno);?></td>
        <td>
        <?php echo htmlentities($result->apellido);?>, <?php echo htmlentities($result->nombre);?>
         </td>
        <td><?php echo $result->nom_cargo;?> (<?php echo $result->nom_area;?>)</td>                                 

        <td style='text-align:right'>
        <?php 
        #$nb=number_format($result->sueldo,2);
        $nb=number_format($result->sueldo,2,".",",");
        echo $nb;
        ?>
        </td>
        <td>
        <!-- Descuentos -->
          <table>
          <tr>
          <?php
          $basico=$result->sueldo;
          $idpersona=$result->id;
          $ttdsto=0;
          $sql1 = "SELECT * from tipo_descuento where estado='1' order by 1 asc";
          $query1 = $dbh->prepare($sql1);
          $query1->execute();
          $results1=$query1->fetchAll(PDO::FETCH_OBJ);
          foreach($results1 as $results1){   
          
          $idtdstper=$results1->iddescuento;
          $sqld = "SELECT idtdsto, valor_dscto from descuento_personal as dp where id_personal='$idpersona' 
          and id_planilla='$tipopla' and id_periodo='$nperi' and nummes='$numes' and id_tipo_dscto='$idtdstper' 
          and dp.estado='1'";
          $querydp = $dbh->prepare($sqld);
          $querydp->execute();
          $resultsDp=$querydp->fetchAll(PDO::FETCH_OBJ);
           
           if($querydp->rowCount() > 0){
             foreach($resultsDp as $resultsDp){   
             $ttdsto=$ttdsto+$resultsDp->valor_dscto;
             ?>
             <td style="text-align:right;background-color: #FFD9FA;"><?php echo number_format($resultsDp->valor_dscto,2,".",",")?></td>
            <?php 
            }
          }else{
          ?>
           <td style='text-align:right;background-color: #FFD9FA;width:30px;'>0.00</td>
        <?php
          }
        }
          ?>
          </tr></table>
       </td> 
       <td>  
       <!-- Bonificaciones -->   
       <table>
       <tr>  
         <?php
          $ttbinf=0;
          $sql2= "SELECT * from tipo_bonificacion where estado='1' order by 1 asc";
          $query2 = $dbh->prepare($sql2);
          $query2->execute();
          $results2=$query2->fetchAll(PDO::FETCH_OBJ);
          foreach($results2 as $results2){   
          
          $idtbonfper=$results2->idbonificacion;
          $sqlb = "SELECT idbonfi, valor_bonfi from bonificacion_personal as dp where idpersonal='$idpersona' 
          and idplanilla='$tipopla' and idperiodo='$nperi' and nummes='$numes' and id_tipo_bonifi='$idtbonfper' 
          and dp.estado='1'";
          $querybp = $dbh->prepare($sqlb);
          $querybp->execute();
          $resultsBp=$querybp->fetchAll(PDO::FETCH_OBJ);
           
           if($querybp->rowCount() > 0){
             foreach($resultsBp as $resultsBp){   
             $ttbinf=$ttbinf+$resultsBp->valor_bonfi;
             ?>
            <td style="text-align:right;background-color: #DCFFFA;"><?php echo number_format($resultsBp->valor_bonfi,2,".",",")?></td>
            <?php 
            }
          }else{
           ?>
           <td style='text-align:right;background-color: #DCFFFA;width:30px;'>0.00</td>
        <?php
          }
        }         
       ?>
       </tr>
       </table>
      <?php 
      $sueldoneto= ($basico-$ttdsto)+$ttbinf;        
     $td=number_format($ttdsto,2);
     $tb=number_format($ttdsto,2);
     #$sn=number_format($sueldoneto,2);       
     
     $sn=sprintf("%0.2f", $sueldoneto);
      ?> 
       </td>
  
       
       <td style="text-align:right;"><?php echo $td;?></td>
       <td style="text-align:right;"><?php echo $tb;?></td>
       <td style="text-align:right;mso-number-format:"\#\,\#\#0\.00""><?php echo $sueldoneto;?></td>
    
      
    </tr>
    <?php $cnt++;} }?>
   </tbody>
   </table>
  
                   
</div>

</div>
                                
</div>
                            
                            
             
                    </div>
                </div>
            </main>
         
        </div>
        <div class="left-sidebar-hover"></div>
    </body>
</html>
<?php } ?>

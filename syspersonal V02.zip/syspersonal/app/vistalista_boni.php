<?php
session_start();
error_reporting(0);
include('../includes/config.php');
include('../includes/funciones.php');
if(strlen($_SESSION['emplogin'])==0){   
header('location:index.php');
}else{ 

#if(isset($_POST['qhago'])){  


if(isset($_POST['del'])){
$id=$_POST['del'];  
$sql = "update descuento_personal set estado='0' where idtdsto=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();
$msg="Registro de Descuento eliminado";
#echo "es: $id";
}

if(isset($_POST['add'])){

#Periodo y planilla activo
$idpla=1;
$idtyear=1;
$estado=1;

$idper=$_POST['add'];
$idp=getCodigo($dbh,'descuento_personal','idtdsto'); # Obtenemos el codigo del nuevo registro
$idper=$_POST['idper'];
$idsto=$_POST['idsto'];
$imp=$_POST['imp'];

                         
$sql="INSERT INTO descuento_personal(idtdsto,id_tipo_dscto,id_personal,id_planilla,id_periodo,valor_dscto,estado) VALUES ('$idp','$idsto','$idper','$idpla','$idtyear','$imp','$estado')";
$query=$dbh->prepare($sql);
$query->execute();
$msg="Registro de Descuento con exito";
}

#== Obtener id de Planilla Activa / Abierta.

$sqltp = "SELECT cp.*,tp.nameplanilla,pr.nameperiodo from configurar_planilla as cp INNER JOIN tipoplanilla as tp on cp.idtipopla=tp.idtipoplanilla
Inner Join periodo as pr ON cp.idperiodo=pr.idperiodo where cp.estado='1' order by 1 limit 1";
$queryTP = $dbh->prepare($sqltp);
$queryTP->execute();
$resultsTP=$queryTP->fetchAll(PDO::FETCH_OBJ);
if($queryTP->rowCount()>0){
 foreach($resultsTP as $resultsTP){ 
   $nper=$resultsTP->nameperiodo;
   $nplan=$resultsTP->nameplanilla;
   $numes=$resultsTP->numes;
 }
 
 if($numes=='01') $nmes='Enero';
 if($numes=='02') $nmes='Febero';
 if($numes=='03') $nmes='Marzo';
 if($numes=='04') $nmes='Abril';
 if($numes=='05') $nmes='Mayo';
 if($numes=='06') $nmes='Junio';
 if($numes=='07') $nmes='Julio';
 if($numes=='08') $nmes='Agosto';
 if($numes=='09') $nmes='Septiembre';
 if($numes=='10') $nmes='Octubre';
 if($numes=='11') $nmes='Noviembre';
 if($numes=='12') $nmes='Diciembre';
 
 $nplac=$nplan.' '.$nmes.'-'.$nper;
 $colorpla='#A5E882';
}else{
 $nplac="<font color='red'>Debe de Aperturar Planilla</font>";
 $colorpla='#F7D4BC';
}

?>

<table id="examples3">
                  <thead>
                  <tr style='background-color: <?php echo $colorpla;?>;'><th colspan="4">
                   &raquo; Afecto a Planilla de: [<?php echo $nplac;?>]
                  </th></tr>
                  <tr style='height:10px;background-color:#CBDBFE'>
                  <td>Id</td>
                  <td width='220px'>Concepto</td>
                  <td>Importe</td>
                  <td></td>
                  </tr>
                  </thead>
<?php

$did=intval($_POST['id']);  

$sql = "SELECT dp.*,td.namedescuento from descuento_personal as dp Inner Join tipo_descuento as td ON dp.id_tipo_dscto=td.iddescuento  
WHERE id_personal=:did and dp.estado='1'";
$query = $dbh -> prepare($sql);
$query->bindParam(':did',$did,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount()>0){
foreach($results as $result){  
                                                               
?>
<tr>
<td><?php echo htmlentities($result->id_tipo_dscto);?></td>
<td><?php echo htmlentities($result->namedescuento);?></td>
<td align='right'><?php echo $result->valor_dscto;?></td>
<td><a href='#' onclick="eliminar('<?php echo $result->idtdsto;?>','<?php echo $did;?>')"> <i class="material-icons">delete_forever</i></a></td>
</tr>

<?php   
 }
}
#}
?> 

 </table>

 <?php }?>     
            
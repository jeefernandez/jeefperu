<?php
session_start();
error_reporting(0);
include('../includes/config.php');
if(strlen($_SESSION['emplogin'])==0)
    {   
header('location:index.php');
}
else{ 
if(isset($_GET['del']))
{
$id=$_GET['del'];
#$sql = "delete from  configurar_planilla  WHERE idconfig=:id";
$sql = "update  configurar_planilla set estado='0'  WHERE idconfig=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();
$msg="Registro del Planilla eliminado";

}

#llenar lista de Periodos
$sqlp = "SELECT * from periodo where estado='1' order by 1";
$queryP = $dbh->prepare($sqlp);
$queryP->execute();
$resultsPer=$queryP->fetchAll(PDO::FETCH_OBJ);

$nperi=$_POST["lstper"];
    ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        
        <!-- Title -->
        <title>Admin | Administrar Apertura de Planillas</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />
        
        <!-- Styles -->
        <link type="text/css" rel="stylesheet" href="../assets/plugins/materialize/css/materialize.min.css"/>
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="../assets/plugins/material-preloader/css/materialPreloader.min.css" rel="stylesheet">
        <link href="../assets/plugins/datatables/css/jquery.dataTables.min.css" rel="stylesheet">

            
        <!-- Theme Styles -->
        <link href="../assets/css/alpha.min.css" rel="stylesheet" type="text/css"/>
        <link href="../assets/css/custom.css" rel="stylesheet" type="text/css"/>
<style>
  .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #E0B769;
    color:#fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 5px;
    margin: 0 0 20px 0;
    background: #5cb85c;
    color:#fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
        </style>
<script>
function ver_data(){
   frm.submit();
}
</script>        
    </head>
    <body>
       <?php include('../includes/header.php');?>
            
       <?php include('../includes/sidebar.php');?>
            <main class="mn-inner">
                <div class="row">
                    <div class="col s12">
                        <div class="page-title">Administrar Apertura y Cierre de planillas</div>
                    </div>
                    <div class="col s12 m12 l12">
                        <div class="card">
                            <div class="card-content">

                                <span class="card-title">

<div class="input-field col s2">
Mostrar x Periodo
</div>
<form action='conf_plan.php' name='frm' method='POST'>  <!-- Otra pagina igual es: config_planilla.php -->
<div class="input-field col s4">
          <select id='lstper' name='lstper' onchange='ver_data();'>
           <option value=''>...Elija</option>
           <?php
           if($queryP->rowCount() > 0){
           foreach($resultsPer as $resultsPer){   
           ?>
          <option value="<?php echo $resultsPer->idperiodo;?>"<?php if ($nperi==$resultsPer->idperiodo) echo " Selected"?>><?php echo $resultsPer->nameperiodo;?></option>
          <?php 
          }
         }else{  ?> 
        <option value=''>No hay datos</option>
        <?php }    ?>
       </select>  
</div>
</form>

                                
<div class="input-field col s6">
 <a href="addplanilla.php?deptid=0">
 <button name="update" class="waves-effect waves-light btn indigo m-b-xs">Crear Planilla</button>
 </a>
</div>

 </span>

 <?php if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>

<table id="example" class="display responsive-table">
<?php
                                 #ID de tabla es para paginación y busqueda con libreria Boostrap
?>
 <thead>
                                        <tr>
                                            <th>Nro </th>
                                            <th>Periodo</th>
                                            <th>Mes</th>
                                            <th>Tipo Planilla</th>
                                            <th>Estado</th>
                                            <th>Observación</th>
                                            <th>Accion</th>
                                        </tr>
                                    </thead>
                                 
                                    <tbody>
<?php 

if($nperi==''){
  $sql = "SELECT cp.*,pr.nameperiodo, namecorto,nameplanilla from configurar_planilla as cp 
  INNER JOIN periodo as pr ON cp.idperiodo=pr.idperiodo
  INNER JOIN tipoplanilla as tp ON cp.idtipopla=tp.idtipoplanilla order by 1";
}else{
   $sql = "SELECT cp.*,pr.nameperiodo, namecorto,nameplanilla from configurar_planilla as cp 
  INNER JOIN periodo as pr ON cp.idperiodo=pr.idperiodo
  INNER JOIN tipoplanilla as tp ON cp.idtipopla=tp.idtipoplanilla where cp.idperiodo='$nperi' order by 1";
}
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{  
 if($result->numes=='01') $nmes='Enero';
 if($result->numes=='02') $nmes='Febero';
 if($result->numes=='03') $nmes='Marzo';
 if($result->numes=='04') $nmes='Abril';
 if($result->numes=='05') $nmes='Mayo';
 if($result->numes=='06') $nmes='Junio';
 if($result->numes=='07') $nmes='Julio';
 if($result->numes=='08') $nmes='Agosto';
 if($result->numes=='09') $nmes='Septiembre';
 if($result->numes=='10') $nmes='Octubre';
 if($result->numes=='11') $nmes='Noviembre';
 if($result->numes=='12') $nmes='Diciembre';
 
 #== Estado de Planilla
  if($result->estado=='0'){
    $msn="Aulada";
    $colormsn='#FBC3B8';
  }else if($result->estado=='1'){
    $msn="Abierta";
    $colormsn='#7CF965';
  }else if($result->estado=='2'){
    $msn="Cerrada";
    $colormsn='#C1C3D2';
  }
 
 ?>  
                                        <tr>
                                            <td><?php echo htmlentities($cnt);?></td>
                                            <td><?php echo htmlentities($result->nameperiodo);?></td>
                                            <td><?php echo htmlentities($nmes);?></td>
                                            <td><?php echo htmlentities($result->nameplanilla);?></td>
                                            <td>
                                            <div style="background-color: <?php echo $colormsn;?>;text-align:center;border-radius: 20px;">
                                              <?php echo $msn;?></div>
                                            </td>
                                            <td><?php echo $result->obs;?></td>
                                            <td><a href="editplanilla.php?deptid=<?php echo htmlentities($result->idconfig);?>">
                                            <i class="material-icons">mode_edit</i></a>
                                            <a href="conf_plan.php?del=<?php echo htmlentities($result->idconfig);?>" onclick="return confirm('Estas seguro de ANULAR?');"> <i class="material-icons">delete_forever</i></a></td>
                                        </tr>
                                         <?php $cnt++;} }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
         
        </div>
        <div class="left-sidebar-hover"></div>
        
        <!-- Javascripts -->
        <script src="../assets/plugins/jquery/jquery-2.2.0.min.js"></script>
        <script src="../assets/plugins/materialize/js/materialize.min.js"></script>
        <script src="../assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
        <script src="../assets/plugins/jquery-blockui/jquery.blockui.js"></script>
        <script src="../assets/plugins/datatables/js/jquery.dataTables.min.js"></script>
        <script src="../assets/js/alpha.min.js"></script>
        <script src="../assets/js/pages/table-data.js"></script>
        
    </body>
</html>
<?php } ?>
<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					});
		   </script>